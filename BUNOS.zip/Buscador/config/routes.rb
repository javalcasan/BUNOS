Rails.application.routes.draw do
  devise_for :users
  resources :medios
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

	root 'busquedas#new'

  resources :busquedas 
  get 'error' => "busquedas#resultados"
end
