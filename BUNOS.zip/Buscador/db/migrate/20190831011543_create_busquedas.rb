class CreateBusquedas < ActiveRecord::Migration[5.2]
  def change
    create_table :busquedas do |t|
      t.string :titular
      t.string :link
      t.date :fechareal
      t.string :medio

      t.timestamps
    end
  end
end
