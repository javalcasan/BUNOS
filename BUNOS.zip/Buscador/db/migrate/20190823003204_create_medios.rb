class CreateMedios < ActiveRecord::Migration[5.2]
  def change
    create_table :medios do |t|
      t.string :medio
      t.string :link

      t.timestamps
    end
  end
end
