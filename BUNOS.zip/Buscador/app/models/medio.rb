class Medio < ApplicationRecord

	validates :medio, :presence => true, :uniqueness => true
	validates :link, :presence => true, :uniqueness => true, :format => /\A(www\.)*(\w+\.)(\w{2,3})\z/

end
