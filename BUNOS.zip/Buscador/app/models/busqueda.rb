class Busqueda < ApplicationRecord
	
	def self.to_csv
    attributes = %w{fechareal medio titular link}

    CSV.generate(headers: true) do |csv|
      csv << attributes

      all.each do |busqueda|
        csv << attributes.map{ |attr| busqueda.send(attr) }
      end
    end
  end

end
