module ApplicationHelper

  def ordenable(column, title = nil)
    title ||= column.titleize
    direction = (column == ordena_columna && direccion_del_orden == "asc") ? "desc" : "asc"
    link_to title, :sort => column, :direction => direction
  end

end
