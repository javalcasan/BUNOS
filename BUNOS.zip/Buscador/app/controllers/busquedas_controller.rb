class BusquedasController < ApplicationController
	before_action :set_buscar, only: [:create]
	before_action :set_resultados, only: [:create]
  before_action :set_mediae, only: [:new, :create]
  before_action :set_medios_seleccionados, only: [:create] 

  helper_method :ordena_columna, :direccion_del_orden

	def new
    if Busqueda.count != 0
       Busqueda.delete_all
    end
    @busqueda = Busqueda.new
	end

	def create
    set_errores
    if @errores!=0
      redirect_to :action => 'resultados', :id => @errores
    else
  		busca_noticias(@buscar)
      @resultados.each do |resultado|
        @busqueda = Busqueda.new(:titular => resultado[0], :link => resultado[1], :fechareal => resultado[2], :medio => resultado[3])
        @busqueda.save
      end
      redirect_to :action => 'index'
    end
	end
  
  def index
    @busqueda = Busqueda.order(ordena_columna + ' ' + direccion_del_orden)
    respond_to do |format|
      format.html
      format.csv { send_data @busqueda.to_csv, filename: "busqueda-#{Time.now}.csv" }
    end
  end

  def resultados
    @errores = params[:id].to_i
  end



  private

    # Use callbacks to share common setup or constraints between actions.
    def set_buscar
      @buscar = params[:buscar]
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def busqueda_params
      params.require(:busqueda).permit(:tema, :titulo, :articulo)
    end

    def set_resultados
    	@resultados = []
    end

    def set_mediae
      @mediae = Medio.all
    end

    def set_medios_seleccionados
      #Controlamos que no haya errores de parametros no permitidos...
      @medios_seleccionados = []
      @mediae.each do |medio|
        if @buscar["#{medio.id}"]=="1"
          @medios_seleccionados << [medio.medio,medio.link]
        end
      end
    end

    def set_errores

      no_hay_tema = @buscar[:tema].blank? && @buscar[:titulo].blank? && @buscar[:articulo].blank?
      no_hay_medios = @medios_seleccionados.empty?

      if no_hay_tema && no_hay_medios
        @errores = 3
      elsif no_hay_medios
        @errores = 2
      elsif no_hay_tema
        @errores = 1
      else
        @errores = 0
      end
    end

    def busca_noticias mi_busqueda

        # Establecemos la parte principal de la cabecera URI
        url_base = "https://www.google.com/search?hl=es&tbm=nws&q="

        #Vamos añadiendo términos de búsqueda:
        terminos = []

        #Tema:       cambiar espacios por '+'
        if !mi_busqueda[:tema].blank?
          terminos << mi_busqueda[:tema].squish!.gsub(" ","+")
        end
        #Titular: 
        if !mi_busqueda[:titulo].blank?
          terminos << "intitle%3A#{mi_busqueda[:titulo].squish!.gsub(" ","+")}"
        end   
        #Articulo:
        if !mi_busqueda[:articulo].blank?
          terminos << "intext%3A#{mi_busqueda[:articulo].squish!.gsub(" ","+")}"
        end
        #Fecha inicio: 
        if !mi_busqueda[:fecha_inicio].blank?
          terminos << "after%3A#{mi_busqueda[:fecha_inicio]}"
        end
        #Fecha fin:    
        if !mi_busqueda[:fecha_fin].blank?
          terminos << "before%3A#{mi_busqueda[:fecha_fin]}"
        end
        #Sitio: 
        terminos << "site%3A"
        terminos.each do |termino|
          if termino == "site%3A"
            url_base <<  "#{termino}"
          else
            url_base << "#{termino}+"
          end
        end
        #Con la URI preparada, creo una variable para encadenar la lista de noticias
        listaNoticias = []
        #Variable auxiliar para cálculo de fechas
        mesbruto = [" ene. "," feb. "," mar. "," abr. "," may. "," jun. "," jul. "," ago. "," sept. "," oct. "," nov. "," dic. "]
        
        #Preparo el buscador que voy a utilizar.
        #Explorador donde voy a buscar con chrome headless
        opciones_buscador = Selenium::WebDriver::Chrome::Options.new
        opciones_buscador.add_argument('--headless')
        explorador = Selenium::WebDriver.for :chrome, options: opciones_buscador

        #Para cada medio,
        @medios_seleccionados.each do |medio|
          if mi_busqueda[:noticias_por_medio].to_i<=0
            maxResXMedio = 10
          else
            maxResXMedio = mi_busqueda[:noticias_por_medio].to_i
          end
          url = "#{url_base}#{medio[1]}"

          #Mientras el número de resultados máximos sea estrictamente positivo
          explorador.get(url)
          #Si la pagina carga ok

          finito = 0
          paginaActual = 0


          #Buscamos por página los resultados hasta que no haya más o lleguemos al máximo 
          #de resultados por medio establecido:

          #Hasta que se acaben los resultados o lleguemos al número requerido...
          until finito > 0
            resultado = 0

            #... mientras queden por mirar noticias...
            while !explorador.find_elements(:class, "l").to_a[resultado].nil? && maxResXMedio >0 

              #1.- Extraemos el titular, el link y la fecha.
              titular  = explorador.find_elements(:class, "l")[resultado].text
              link = explorador.find_elements(:class, "l")[resultado]['href']
              fechabruto = explorador.find_elements(:class,"slp")[resultado].find_elements(:class, "f")[0].text

              #2.- Formateamos la fecha
              tiempoConsulta = Time.now
              if fechabruto.split[2][0] == "m" #La fecha está en formato: "Hace X minutos"
                minutoPublicacion = tiempoConsulta.min - fechabruto.split[1].to_i
                horaPublicacion = tiempoConsulta.hour - fechabruto.split[1].to_i
                if minutoPublicacion >=0 
                  fechareal = tiempoConsulta.to_date
                elsif horaPublicacion >=0 
                  fechareal = tiempoConsulta.to_date
                else
                  fechareal = tiempoConsulta.to_date.prev_day
                end
              elsif fechabruto.split[2][0] == "h" #La fecha está en formato: "Hace X horas"
                horaPublicacion = tiempoConsulta.hour - fechabruto.split[1].to_i
                if horaPublicacion >=0 
                  fechareal = tiempoConsulta.to_date
                else
                  fechareal = tiempoConsulta.to_date.prev_day
                end
              else 
                for i in (0..11) #La fecha está en formato: "dd mmm. aaaa"
                  fechabruto.gsub!(mesbruto[i],"-#{i+1}-")
                end
                fechareal=Date.parse(fechabruto)
              end
              noticiaExtraida = [titular, link, fechareal, medio[0]]
              #3.- Comprobamos que la noticia no exista y si es así la incluimos y la contamos.
              if !listaNoticias.include?(noticiaExtraida)
                maxResXMedio -= 1
                listaNoticias << noticiaExtraida
              end
              resultado += 1

            end 

            if maxResXMedio == 0 # Se alcanza el máximo número de resultados por medio
              finito = 1
            elsif resultado == 0  # Ya no hay más resultados para esta búsqueda
              finito = 2
            else                  # Pasamos a la página siguiente
              paginaActual += 1
              explorador.get("#{url}&start=#{paginaActual*10}")
            end
          end
        end
        @resultados = listaNoticias.sort_by {|el| el[2] }
    end
    def ordena_columna
      Busqueda.column_names.include?(params[:sort]) ? params[:sort] : "fechareal"
    end
  
    def direccion_del_orden
      %w[asc desc].include?(params[:direction]) ?  params[:direction] : "desc"
    end
end
