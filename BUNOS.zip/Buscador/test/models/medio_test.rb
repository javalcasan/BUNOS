require 'test_helper'

class MedioTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
