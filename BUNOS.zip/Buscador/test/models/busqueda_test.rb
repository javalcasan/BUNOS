require 'test_helper'

class BusquedaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
